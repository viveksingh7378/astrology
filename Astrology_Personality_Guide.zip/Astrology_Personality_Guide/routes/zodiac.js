// routes/zodiac.js
const express = require('express');
const router = express.Router();
const ReadAction = require('../models/ReadAction');

router.post('/read', async (req, res) => {
    try {
        const { sign, timestamp } = req.body;
        const read = new ReadAction({ sign, timestamp });
        await read.save();
        res.status(201).json({ message: 'Read action saved', read });
    } catch (err) {
        res.status(500).json({ message: 'Failed to save read action' });
    }
});

module.exports = router;
