// models/ReadAction.js
const mongoose = require('mongoose');

const readSchema = new mongoose.Schema({
    sign: String,
    timestamp: { type: Date, default: Date.now }
});

module.exports = mongoose.model('ReadAction', readSchema);

